import java.util.Scanner;

public class Department {
    private int departmentNumber;
    private String departmentName;
    private Course[] courses;
    private Lecturer[] lecturers;
    Scanner scanner= new Scanner(System.in);

    public Department(int departmentNumber, String departmentName, Course[] courses, Lecturer[] lecturers) {
        this.departmentNumber = departmentNumber;
        this.departmentName = departmentName;
        this.courses = courses;
        this.lecturers = lecturers;
    }

    public int getDepartmentNumber() {
        return departmentNumber;
    }

    public void setDepartmentNumber(int departmentNumber) {
        this.departmentNumber = departmentNumber;
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setDepartmentName(String departmentName) {
        this.departmentName = departmentName;
    }

    public Course[] getCourses() {
        return courses;
    }

    public void setCourses(Course[] courses) {
        this.courses = courses;
    }

    public Lecturer[] getLecturers() {
        return lecturers;
    }

    public void setLecturers(Lecturer[] lecturers) {
        this.lecturers = lecturers;
    }
    public void print(){
        System.out.println("Department name: "+departmentName);
        System.out.println("Department number: "+departmentNumber);
        System.out.println("Department lecturers: ");
        for (int i=0;i<lecturers.length;i++){
            if (lecturers[i]!=null){
                System.out.println(i+1+": "+lecturers[i].getFirstName()+" "+lecturers[i].getLastName());
                this.lecturers[i].print();
            }
        }
        System.out.println("Department courses: ");
        for (int i=0;i<courses.length;i++){
            if (courses[i]!=null){
                System.out.println(i+1+": "+courses[i].getCourseName());
                this.courses[i].print();
            }
        }

    }
    public void addLecturer(){
        System.out.println("Pleas enter lecturer first name: ");
        String lecturerFirstName=scanner.nextLine();
        System.out.println("Pleas enter lecturer last name: ");
        String lecturerLastName=scanner.nextLine();
        System.out.println("Pleas enter lecturer years of seniority: ");
        int yearsOfSeniority=scanner.nextInt();
        for (int i=0;i<lecturers.length;i++){
            if (lecturers[i]==null){
                lecturers[i]=new Lecturer(lecturerFirstName,lecturerLastName,yearsOfSeniority);
                break;
            }
        }
        System.out.println("Successfully added");


    }
    public void addCourse(){
        Student[] students=new Student[0];

        if (lecturers[0]!=null&&lecturers[1]==null){
            System.out.println("Pleas enter the Course name: ");
            String courseNew = scanner.nextLine();
            for (int i=0;i<courses.length;i++){
                if (courses[i]==null){
                    courses[i]=new Course(courseNew,this.lecturers[0],students);
                    break;
                }
            }
            System.out.println("Successfully added!");
        }else if ((lecturers[0]!=null)&&(lecturers[1]!=null)){
            System.out.println("Pleas enter the Course name: ");
            String course2New = scanner.next();
            System.out.println("This is a list of our lectures");
            for (int i=0;i<lecturers.length;i++){
                if (lecturers[i]!=null){
                    System.out.println(i+1+")"+lecturers[i].getFirstName()+" "+lecturers[i].getLastName());

                }
            }
            System.out.println("Pleas choose a lecture for your course by number");
            int lecturerNumber=scanner.nextInt();
            for (int i=0;i<courses.length;i++){
                if (courses[i]==null){
                    courses[i]=new Course(course2New,lecturers[lecturerNumber-1],students);
                    break;
                }
            }
            System.out.println("Successfully added!");
        }else {
            System.out.println("Sorry we have no lecturers available");
        }


    }
    }

