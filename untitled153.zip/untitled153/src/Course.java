public class Course {
    private String courseName;
    private Lecturer courseLecturer;
    private Student[] courseStudent;

    public Course(String courseName, Lecturer courseLecturer, Student[] courseStudent) {
        this.courseName = courseName;
        this.courseLecturer = courseLecturer;
        this.courseStudent = courseStudent;
    }
    public String getCourseName() {
        return courseName;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    public Lecturer getCourseLecturer() {
        return courseLecturer;
    }
    public void setCourseLecturer(Lecturer courseLecturer) {
        this.courseLecturer = courseLecturer;
    }
    public Student[] getCourseStudent() {
        return courseStudent;
    }
    public void setCourseStudent(Student[] courseStudent) {
        this.courseStudent = courseStudent;
    }
    public void print(){
        System.out.println("The course name: "+this.courseName);
        System.out.println("The lecturer name: "+this.courseLecturer.getFirstName()+" "+this.courseLecturer.getLastName());
        System.out.println("In this course learn "+courseStudent.length+" students");
        System.out.println("List of students name in this course: ");
        for (int i=0;i<courseStudent.length;i++){
            if (courseStudent[i]!=null){
                System.out.println(i+1+") "+courseStudent[i].getFirstName()+" "+courseStudent[i].getLastName());
            }
        }

    }
    public void addStudents(Student student){
        for (int i=0;i<=this.courseStudent.length;i++){
            if (this.courseStudent[i]==null){
                this.courseStudent[i]=student;
                System.out.println("Successfully added");
                break;
            }
        }
    }
}
