public class HeadOfDepartment extends Lecturer {
    private String specialty;
    private String degree;

    public HeadOfDepartment(String firstName, String lastName, int yearsOfSeniority, String specialty, String degree) {
        super(firstName, lastName, yearsOfSeniority);
        this.specialty = specialty;
        this.degree = degree;
    }
    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }

    public String getDegree() {
        return degree;
    }

    public void setDegree(String degree) {
        this.degree = degree;
    }
    public void print(){
        super.print();
        System.out.println("Specialty: "+this.specialty);
        System.out.println("Degree: "+this.degree);

    }
}
