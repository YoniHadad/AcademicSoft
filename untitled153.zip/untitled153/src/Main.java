import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Student student1 =new Student(001,"Yoni","Hadad");
        Student student2 =new Student(002,"Meni","Levi");
        Student student3 =new Student(003,"Geri","Sabag");
        Student student4 =new Student(004,"Shlomi","Menashe");
        Student student5 =new Student(005,"Joni","Hadar");
        Student[] students=new Student[10];
        students[0]=student1;
        students[1]=student2;
        students[2]=student3;
        students[3]=student4;
        students[4]=student5;

        Lecturer lecturer1=new Lecturer("Shai","Givati",10);
        Lecturer lecturer2=new Lecturer("Oren","Levi",20);
        Lecturer lecturer3=new Lecturer("Binyamin","Moati",5);
        Lecturer lecturer4=new Lecturer("Ester","Yarimi",15);
        Lecturer lecturer5=new Lecturer("Efrat","Zoar",10);

        HeadOfDepartment headOfDepartment=new HeadOfDepartment("Haim","Hadar",30,"Sciences","PhD");

        Course course1=new Course("computer",lecturer1,students);
        Course course2=new Course("Engineering",lecturer2,students);
        Course course3=new Course("Sociology",lecturer3,students);
        Course course4=new Course("criminology",lecturer4,students);

        Department[] departments=new Department[6];

        Course[]coursesInDepartment=new Course[4];
        coursesInDepartment[0]=course1;
        coursesInDepartment[1]=course2;
        Lecturer[]lecturersInDepartment=new Lecturer[4];
        lecturersInDepartment[0]=lecturer1;
        lecturersInDepartment[1]=lecturer2;
        departments[0]=new Department(5031,"Sciences",coursesInDepartment,lecturersInDepartment);

        Course[]coursesInDepartment2=new Course[4];
        coursesInDepartment2[2]=course3;
        coursesInDepartment2[3]=course4;
        Lecturer[]lecturersInDepartment2=new Lecturer[4];
        lecturersInDepartment2[2]=lecturer3;
        lecturersInDepartment2[3]=lecturer4;
        departments[1]=new Department(5030,"psychology",coursesInDepartment2,lecturersInDepartment2);
        firstView(departments);
    }
    public static void firstView(Department[]departments){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Pleas choose one of our department: ");
        for (int i=0;i<departments.length;i++){
            if (departments[i]!=null){
                System.out.println(departments[i].getDepartmentName()+" <-press "+(i)+" for enter");
            }
        }
        int userEnter = scanner.nextInt();
        academicMenu(departments,userEnter);
    }

    public static void academicMenu(Department[]departments,int userEnter){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Welcome, you have chose the department "+departments[(userEnter)].getDepartmentName());
        System.out.println("Enter 0 for department information");
        System.out.println("Enter 1 for change the name of the department ");
        System.out.println("Enter 2 to add lecturer to the department");
        System.out.println("Enter 3 to add course to the department");
        System.out.println("Enter 4 to edit one of our course");
        System.out.println("Enter 5 to go back to the main menu");
        int userMenuChoice=scanner.nextInt();
        if (userMenuChoice==0){
            System.out.println("department information: ");
            departments[userEnter].print();
            System.out.println("--------------");
            System.out.println("We send you back to the menu");
            System.out.println("--------------");
            academicMenu(departments,userEnter);
        }
        else if (userMenuChoice==1){
            System.out.println("Enter new name: ");
            String newName=scanner.next();

            departments[userEnter].setDepartmentName(newName);
            firstView(departments);
        }
        else if (userMenuChoice==2){
            departments[userEnter].addLecturer();
            System.out.println("--------------");
            System.out.println("We send you back to the menu");
            System.out.println("--------------");
            academicMenu(departments,userEnter);

        }
        else if (userMenuChoice==3){
            departments[userEnter].addCourse();
            System.out.println("--------------");
            System.out.println("We send you back to the menu");
            System.out.println("--------------");
            academicMenu(departments,userEnter);

        }
        else if (userMenuChoice==4){
            Course[] departmentCourses=departments[userEnter].getCourses();
            for (int i=0;i<departmentCourses.length;i++){
                if (departmentCourses[i]!=null){
                    System.out.println(i+1+") "+departmentCourses[i].getCourseName());
                }
            }
            System.out.println("Pleas choose a course (by number) to edit");
            int courseYouEdit=scanner.nextInt();
            System.out.println("Enter 1 for course information");
            System.out.println("Enter 2 to edit course name");
            System.out.println("Enter 3 to add new student");
            System.out.println("Enter 4 for go back to previous menu");
            int courseEdit=scanner.nextInt();
            switch (courseEdit){
                case 1:
                    departmentCourses[(courseYouEdit-1)].print();
                    break;
                case 2:
                    System.out.println("Enter new name: ");
                    String newCourseName=scanner.next();
                    departmentCourses[(courseYouEdit-1)].setCourseName(newCourseName);
                    academicMenu(departments,userEnter);
                    break;
                case 3:
                  System.out.println("First name:");
                  String studentNewFirst=scanner.next();
                  System.out.println("Last name:");
                  String studentNewLast=scanner.next();
                  System.out.println("Id number:");
                  int studentNewId=scanner.nextInt();
                  departmentCourses[(courseYouEdit-1)].addStudents(new Student(studentNewId,studentNewFirst,studentNewLast));
                  academicMenu(departments,userEnter);
                  break;
                case 4:
                    System.out.println("--------------");
                    System.out.println("We send you back to the menu");
                    System.out.println("--------------");
                    academicMenu(departments,userEnter);
                    break;
            }

        }else if (userMenuChoice==5){
            firstView(departments);

        }



    }
}
