public class Lecturer extends PersonalDetails {
    private int yearsOfSeniority;

    public Lecturer(String firstName, String lastName, int yearsOfSeniority) {
        super(firstName, lastName);
        this.yearsOfSeniority = yearsOfSeniority;
    }

    public int getYearsOfSeniority() {
        return yearsOfSeniority;
    }

    public void setYearsOfSeniority(int yearsOfSeniority) {
        this.yearsOfSeniority = yearsOfSeniority;
    }
    public void print(){
        super.print();
        System.out.println("Years of seniority: "+this.yearsOfSeniority);
    }
}
