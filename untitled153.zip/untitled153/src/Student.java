public class Student extends PersonalDetails {
private int cardNumber;

    public Student(int cardNumber,String firstName,String lastName) {
        super(firstName,lastName);
        this.cardNumber = cardNumber;
    }

    public int getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(int cardNumber) {
        this.cardNumber = cardNumber;
    }
    public void print(){
        super.print();
        System.out.println("Card id"+this.cardNumber);
    }
}
